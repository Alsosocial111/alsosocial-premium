# AlsoSocial — Website setup

## What is included
- `index.html`: all page markup, CSS, animation and browser JavaScript in one file.
- `assets/`: bundled photos and the Canva concept image. Keep this folder with index.html.
- `contact/index.html` and `what-we-do/index.html`: directly accessible page entry points.
- `api/contact.mjs`: private server-side enquiry email handler for Vercel.
- `vercel.json`: navigation and response-header configuration.
- `.env.example`: environment variable names; never put a real API key into HTML or GitHub.

The site has Home, What We Do and Contact pages. The original service copy is preserved. The discovery-call button opens an enquiry form; it does not automatically reserve a calendar slot. Concept mockups are illustrative, not client work or measured campaign results.

## Deploy to GitHub → Vercel
1. Unzip the download on your computer.
2. Create a GitHub repository. Upload the CONTENTS of the extracted folder: index.html, assets, api, contact, what-we-do and vercel.json should be at the repository root.
3. In Vercel, choose Add New → Project and import this repository.
4. Use Framework Preset **Other**. Leave Build Command empty and set Output Directory to `.` (the project root). Keep the Root Directory at the repository root.
5. Deploy. Home, /what-we-do/ and /contact/ will load. The Talk to us button opens the visitor's email application.
6. Finish the email setup below, redeploy, then send a real enquiry and verify receipt in Gmail before promoting the website.

## Activate private form email delivery
The design is ready, but sending is NOT activated. The static Sites preview cannot run the Vercel email function. On Vercel, missing credentials cause a clear error instead of a false success message.

1. Open https://resend.com and create or use your sending account.
2. Add `wealsosocial.com` as a sending domain. Add the DNS records Resend supplies at your domain provider. Wait for the domain to show verified. Only use a domain you control.
3. Create a sending API key. Keep it private.
4. In Vercel → your project → Settings → Environment Variables, add these for Production (and Preview if you want to test preview deployments):
   - `RESEND_API_KEY`: your private Resend API key.
   - `CONTACT_TO`: `varunn3105@gmail.com`
   - `CONTACT_FROM`: `AlsoSocial <website@wealsosocial.com>` (must use your verified sending domain).
5. Redeploy from Vercel → Deployments so the environment variables take effect.
6. Submit a test enquiry. Confirm it arrives in the destination Gmail inbox, check Spam if necessary, and reply to confirm the visitor's email is set as Reply-To.

The Gmail destination is an environment variable, not part of the browser page or JavaScript. Never put the key or recipient in index.html. This is why the small API file is required alongside the HTML.

The handler includes field validation, origin checking, a hidden spam-trap field, timeouts, and idempotency to reduce duplicate delivery on retries. Before a public campaign, configure Vercel Firewall rate limiting for POST /api/contact (for example, a low per-IP enquiry limit appropriate for your traffic). The honeypot alone is not a complete spam defence. Email provider costs and limits depend on your account; review them before enabling campaigns.

## Editing
Edit the main `index.html`. The route entry copies use the same file with `<base href="/">` inserted in the head; copy your updated index.html into the two route folders and retain that base element. Update public email links, service copy and social links in the HTML. CSS variables near the top control colours.

Opening index.html directly supports page switching through query parameters. The form requires deployment to Vercel to send. Images are local; fonts load from Google Fonts and fall back to the system sans-serif if unavailable.

## Assets and design
Canva editable concept layout: https://canva.link/it1434neq7ep1ix
The included Canva image is its available preview-resolution thumbnail, used at a modest display size. A higher-resolution Canva PNG export can replace `assets/canva-concepts.png` later.
Photographs: Unsplash image IDs photo-1611892440504-42a792e24d32, photo-1629909613654-28e377c37b09, photo-1600210492486-724fe5c67fb0, photo-1441986300917-64674bd600d8.
Google Ads and Meta symbols identify service platforms; no partnership or certification is claimed.

## Verification
Desktop visual review, 390px mobile hero/menu review, direct-page navigation, browser form validation/error behaviour, and mocked server email tests. Real email delivery requires your credentials and has not been verified. The static Sites preview is private to its owner; the Vercel deployment is your separate public hosting setup.

Technical references: https://vercel.com/docs/functions/runtimes/node-js and https://resend.com/docs/api-reference/emails/send-email
